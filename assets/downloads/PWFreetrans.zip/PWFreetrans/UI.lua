-- ============================================================================
--  PW Freetrans LoL - Gildenerfolge
--  Interface: Hauptfenster (Übersicht / Erfolge / Ränge / Gilde), Minimap-Knopf, Toasts.
-- ============================================================================
local ADDON, ns = ...
local C = ns.Config

local UI = {}
ns.UI = UI

local ROW_H = 32
local BACKDROP_TMPL = BackdropTemplateMixin and "BackdropTemplate" or nil
local ORANGE = "|cffff8000"

local DARK_BACKDROP = {
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 },
}

-- ----------------------------------------------------------------------------
--  Scroll-Liste (wiederverwendbar)
--  Zeilen: { header = true, title = "..." } oder
--          { icon, desaturate, title, sub, right, right2, highlight }
-- ----------------------------------------------------------------------------
local function CreateList(parent)
    local scroll = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(1, 1)
    scroll:SetScrollChild(content)
    scroll:SetScript("OnSizeChanged", function(_, w) content:SetWidth(w) end)

    local list = { scroll = scroll, content = content, rows = {} }

    function list:GetRow(i)
        local row = self.rows[i]
        if row then return row end
        row = CreateFrame("Frame", nil, content)
        row:SetHeight(ROW_H)
        row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
        row:SetPoint("RIGHT", content, "RIGHT", 0, 0)

        row.bg = row:CreateTexture(nil, "BACKGROUND")
        row.bg:SetAllPoints()
        row.bg:SetColorTexture(1, 1, 1, 0)

        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(26, 26)
        row.icon:SetPoint("LEFT", 4, 0)

        row.right = row:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        row.right:SetPoint("RIGHT", -8, 0)
        row.right2 = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.right2:SetPoint("RIGHT", row.right, "LEFT", -14, 0)

        row.title = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        row.title:SetJustifyH("LEFT")
        row.title:SetWordWrap(false)
        row.sub = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.sub:SetJustifyH("LEFT")
        row.sub:SetWordWrap(false)

        -- Tooltip mit allen Details (lange Texte werden in der Zeile abgeschnitten)
        row:EnableMouse(true)
        row:SetScript("OnEnter", function(self)
            local tip = self.data and self.data.tooltip
            if not tip then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(tip[1])
            for k = 2, #tip do GameTooltip:AddLine(tip[k], 1, 1, 1, true) end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)

        self.rows[i] = row
        return row
    end

    function list:SetData(data)
        for i, d in ipairs(data) do
            local row = self:GetRow(i)
            row:Show()
            row.data = d
            row.title:ClearAllPoints()
            row.sub:ClearAllPoints()
            if d.header then
                row.bg:SetColorTexture(1, 0.5, 0, 0.18)
                row.icon:Hide()
                row.title:SetFontObject("GameFontNormalLarge")
                row.title:SetPoint("LEFT", 8, 0)
                row.title:SetPoint("RIGHT", -8, 0)
                row.title:SetText(d.title)
                row.sub:SetText("")
                row.right:SetText(d.right or "")
                row.right2:SetText("")
            else
                if d.highlight then
                    row.bg:SetColorTexture(0, 1, 0, 0.10)
                elseif i % 2 == 0 then
                    row.bg:SetColorTexture(1, 1, 1, 0.04)
                else
                    row.bg:SetColorTexture(1, 1, 1, 0)
                end
                local hasIcon = d.icon ~= nil
                row.icon:SetShown(hasIcon)
                if hasIcon then
                    row.icon:SetTexture(d.icon)
                    row.icon:SetDesaturated(d.desaturate and true or false)
                    row.icon:SetAlpha(d.desaturate and 0.5 or 1)
                end
                local anchor, x = hasIcon and row.icon or row, hasIcon and 8 or 8
                local point = hasIcon and "RIGHT" or "LEFT"
                row.title:SetFontObject("GameFontNormal")
                if d.sub and d.sub ~= "" then
                    row.title:SetPoint("BOTTOMLEFT", anchor, point, x, 1)
                    row.sub:SetPoint("TOPLEFT", anchor, point, x, -1)
                    row.sub:SetPoint("RIGHT", row.right2, "LEFT", -8, 0)
                else
                    row.title:SetPoint("LEFT", anchor, point, x, 0)
                end
                row.title:SetPoint("RIGHT", row.right2, "LEFT", -8, 0)
                row.title:SetText(d.title or "")
                row.sub:SetText(d.sub or "")
                row.right:SetText(d.right or "")
                row.right2:SetText(d.right2 or "")
            end
        end
        for i = #data + 1, #self.rows do self.rows[i]:Hide() end
        content:SetHeight(math.max(1, #data * ROW_H))
    end

    return list
end

-- ----------------------------------------------------------------------------
--  Hauptfenster
-- ----------------------------------------------------------------------------
function UI:CreateMainFrame()
    local ok, f = pcall(CreateFrame, "Frame", "PWFreetransFrame", UIParent, "BasicFrameTemplateWithInset")
    if not ok then
        f = CreateFrame("Frame", "PWFreetransFrame", UIParent, BACKDROP_TMPL)
        f:SetBackdrop(DARK_BACKDROP)
        f:SetBackdropColor(0, 0, 0, 0.92)
        local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -2, -2)
    end
    f:SetSize(760, 560)
    f:SetPoint("CENTER")
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetScript("OnShow", function() UI:Refresh() end)
    f:Hide()
    tinsert(UISpecialFrames, "PWFreetransFrame") -- ESC schließt das Fenster

    f.titleText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.titleText:SetPoint("TOP", 0, -5)
    f.titleText:SetText(ORANGE .. "PW Freetrans LoL|r - Klassenerfolge")

    -- Tabs
    f.tabs, f.pages = {}, {}
    local tabNames = { "Übersicht", "Erfolge", "Ränge", "Gilde" }
    for i, name in ipairs(tabNames) do
        local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        b:SetSize(130, 24)
        b:SetPoint("TOPLEFT", 14 + (i - 1) * 136, -30)
        b:SetText(name)
        b:SetScript("OnClick", function() UI:SelectTab(i) end)
        f.tabs[i] = b

        local page = CreateFrame("Frame", nil, f)
        page:SetPoint("TOPLEFT", 14, -62)
        page:SetPoint("BOTTOMRIGHT", -14, 12)
        page:Hide()
        f.pages[i] = page
    end

    self.frame = f
    self:CreateOverviewPage(f.pages[1])
    self:CreateAchievementsPage(f.pages[2])
    self:CreateRanksPage(f.pages[3])
    self:CreateGuildPage(f.pages[4])
    self:SelectTab(1)
end

function UI:SelectTab(i)
    local f = self.frame
    self.currentTab = i
    for j, b in ipairs(f.tabs) do
        if j == i then b:Disable() else b:Enable() end
    end
    self:Refresh()
end

function UI:Toggle()
    if not self.frame then return end
    self.frame:SetShown(not self.frame:IsShown())
end

function UI:Refresh()
    local f = self.frame
    if not f or not f:IsShown() then return end
    for j, page in ipairs(f.pages) do page:SetShown(j == self.currentTab) end
    if self.currentTab == 1 then self:RefreshOverview()
    elseif self.currentTab == 2 then self:RefreshAchievements()
    elseif self.currentTab == 3 then self:RefreshRanks()
    else self:RefreshGuild() end
end

-- ----------------------------------------------------------------------------
--  Seite 1: Übersicht
-- ----------------------------------------------------------------------------
function UI:CreateOverviewPage(page)
    local left = CreateFrame("Frame", nil, page, BACKDROP_TMPL)
    left:SetPoint("TOPLEFT")
    left:SetPoint("BOTTOMLEFT")
    left:SetWidth(450)
    left:SetBackdrop(DARK_BACKDROP)
    left:SetBackdropColor(0, 0, 0, 0.4)

    local o = {}
    o.name = left:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    o.name:SetPoint("TOPLEFT", 16, -16)

    o.points = left:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    o.points:SetPoint("TOPLEFT", o.name, "BOTTOMLEFT", 0, -16)

    o.rank = left:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    o.rank:SetPoint("TOPLEFT", o.points, "BOTTOMLEFT", 0, -10)

    local bar = CreateFrame("StatusBar", nil, left, BACKDROP_TMPL)
    bar:SetPoint("TOPLEFT", o.rank, "BOTTOMLEFT", 0, -12)
    bar:SetSize(410, 20)
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetStatusBarColor(1, 0.5, 0)
    bar:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background" })
    bar:SetBackdropColor(0, 0, 0, 0.6)
    o.barText = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    o.barText:SetPoint("CENTER")
    o.bar = bar

    o.master = left:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    o.master:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -20)
    o.master:SetWidth(410)
    o.master:SetJustifyH("LEFT")

    o.stats = left:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    o.stats:SetPoint("TOPLEFT", o.master, "BOTTOMLEFT", 0, -20)
    o.stats:SetWidth(420)
    o.stats:SetJustifyH("LEFT")
    o.stats:SetSpacing(6)

    local rankTitle = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    rankTitle:SetPoint("TOPLEFT", left, "TOPRIGHT", 14, -4)
    rankTitle:SetText("Ränge")

    local holder = CreateFrame("Frame", nil, page)
    holder:SetPoint("TOPLEFT", left, "TOPRIGHT", 10, -24)
    holder:SetPoint("BOTTOMRIGHT", -24, 0)
    o.rankList = CreateList(holder)
    o.rankList.scroll:SetAllPoints()

    self.overview = o
end

function UI:RefreshOverview()
    local P, o = ns.PWF, self.overview
    local c = P.char
    local cur, nxt = ns.GetRank(c.points)

    o.name:SetText(ns.ClassColored(UnitName("player"), P.classFile) .. ("  -  %s, Stufe %d"):format(P.className, P:GetLevel()))
    o.points:SetText(("%d Klassenpunkte"):format(c.points))
    o.rank:SetText(("Rang %d: |cffffffff%s|r"):format(cur.rank, cur.name))

    if nxt then
        local span = nxt.points - cur.points
        o.bar:SetMinMaxValues(0, span)
        o.bar:SetValue(c.points - cur.points)
        o.barText:SetText(("%d / %d  -  nächster Rang: %s"):format(c.points, nxt.points, nxt.name))
    else
        o.bar:SetMinMaxValues(0, 1)
        o.bar:SetValue(1)
        o.barText:SetText("Höchster Rang erreicht!")
    end

    local master = P:GetClassMasters()[P.classFile]
    local classLabel = ns.ClassColored(ns.ClassName(P.classFile), P.classFile)
    if master and master.name == P.fullName then
        o.master:SetText(("|cffffd100Du bist %s-Klassenmeister der Gilde!|r"):format(classLabel))
    elseif master then
        o.master:SetText(("%s-Klassenmeister: %s (%d Punkte, %s)"):format(classLabel,
            ns.ClassColored(ns.ShortName(master.name), master.class), master.points, ns.RankText(master.points)))
    else
        o.master:SetText(("%s-Klassenmeister: noch niemand"):format(classLabel))
    end

    local dungeonsDone = 0
    for _, n in pairs(c.dungeons) do if n > 0 then dungeonsDone = dungeonsDone + 1 end end
    local W = "|cffffffff%s|r"
    local legendary = P:LegendaryPossible() and "|cff00ff00noch möglich|r" or "|cff808080verwirkt|r"
    o.stats:SetText(table.concat({
        ("Erfolge: " .. W):format(("%d / %d"):format(c.achCount, #P.achievements)),
        ("Gold verdient: %s   Gildenbank: %s"):format(ns.FormatGold(c.goldEarned), ns.FormatGold(c.gbankNet)),
        ("Dungeons: " .. W .. "   Gildenruns: " .. W):format(dungeonsDone .. " / " .. #ns.Data.dungeons, c.guildRuns),
        ("Duelle gewonnen: " .. W .. " (Gilde: " .. W .. ")   Ehrenhafte Siege: " .. W):format(c.duels, c.guildDuels, c.hk),
        ("Serie ohne Tod: " .. W .. " Stufen (Rekord " .. W .. ")   Tode: " .. W):format(c.streak, c.maxStreak, c.deaths),
        ("Punkte aus Stufen ohne Tod: " .. W .. "   Legendär: %s"):format(c.nodeathLevelPoints, legendary),
        ("Gruppenquests allein: " .. W .. "   Spielzeit: " .. W):format(c.soloElite, ("%.0f Std."):format(P:PlayedHours())),
    }, "\n"))

    local rows = {}
    for _, r in ipairs(ns.Data.ranks) do
        local reached = c.points >= r.points
        rows[#rows + 1] = {
            title = ("Rang %d: %s"):format(r.rank, r.name),
            right = (reached and "|cff00ff00" or "|cff808080") .. r.points .. "|r",
            highlight = (r == cur),
        }
    end
    o.rankList:SetData(rows)
end

-- ----------------------------------------------------------------------------
--  Seite 2: Erfolge
-- ----------------------------------------------------------------------------
-- Links eine Spalte mit Kategorie-Knöpfen, rechts die Liste
function UI:CreateAchievementsPage(page)
    self.achFilter = "all"
    self.achFilterButtons = {}
    local filters = { { "all", "Alle" } }
    for _, cat in ipairs(ns.PWF.categories) do filters[#filters + 1] = { cat, cat } end

    for i, fdef in ipairs(filters) do
        local b = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
        b:SetSize(120, 24)
        b:SetPoint("TOPLEFT", 0, -(i - 1) * 27)
        b:SetText(fdef[2])
        b:SetScript("OnClick", function()
            self.achFilter = fdef[1]
            self.achList.scroll:SetVerticalScroll(0)
            self:RefreshAchievements()
        end)
        b.key = fdef[1]
        self.achFilterButtons[i] = b
    end

    local holder = CreateFrame("Frame", nil, page)
    holder:SetPoint("TOPLEFT", 130, 0)
    holder:SetPoint("BOTTOMRIGHT", -24, 0)
    self.achList = CreateList(holder)
    self.achList.scroll:SetAllPoints()
end

-- Zählt dieser Beruf für den Charakter nicht (dritter Hauptberuf)?
local function ProfessionBlocked(P, a)
    if a.type ~= "profession" then return false end
    local p = ns.profByKey[a.key]
    local primary = P.char.primaryProfs
    return p and not p.secondary and #primary >= 2 and not tContains(primary, a.key)
end

function UI:AchievementRow(a)
    local P = ns.PWF
    local c = P.char
    local icon = ns.CategoryIcon(a.cat)
    local rule = (a.rule and a.rule ~= "") and a.rule or nil
    local tooltip = { a.name, a.desc }
    if rule then tooltip[#tooltip + 1] = "|cffffd100Regel:|r " .. rule end

    if a.repeatable then
        local n = c.repeatCounts[a.id] or 0
        tooltip[#tooltip + 1] = ("|cffffd100Punkte:|r +%d je Wiederholung (bisher %dx = %d)"):format(a.points, n, n * a.points)
        return {
            icon = icon, desaturate = n == 0, tooltip = tooltip,
            title = (n > 0 and "|cff00ff00" or "|cffbbbbbb") .. a.name .. "|r  |cff808080(wiederholbar)|r",
            sub = a.desc, right2 = P:GetProgressText(a),
            right = ("|cffffd100+%d|r"):format(a.points),
        }
    end

    local when = c.earned[a.id]
    local sub = a.desc .. (rule and ("  |cff808080(" .. rule .. ")|r") or "")
    if ProfessionBlocked(P, a) then
        sub = "|cffff5555Zählt nicht - nur die ersten zwei Hauptberufe zählen.|r  " .. sub
    end
    if when then
        tooltip[#tooltip + 1] = "|cff00ff00Errungen am " .. date("%d.%m.%Y", when) .. "|r"
    else
        tooltip[#tooltip + 1] = "|cffffd100Fortschritt:|r " .. (P:GetProgressText(a) or "")
    end
    tooltip[#tooltip + 1] = ("|cffffd100Punkte:|r %d"):format(a.points)
    return {
        icon = icon, desaturate = not when, tooltip = tooltip,
        title = (when and "|cff00ff00" or "|cffbbbbbb") .. a.name .. "|r",
        sub = when and ("|cff00ff00Errungen am %s|r  -  %s"):format(date("%d.%m.%Y", when), sub) or sub,
        right2 = not when and P:GetProgressText(a) or "",
        right = (when and "|cffffd100" or "|cff808080") .. a.points .. "|r",
    }
end

-- Zusatzzeilen "Ohne Tod": Punkte pro Stufe je nach Serienlänge
function UI:StreakInfoRows()
    local c = ns.PWF.char
    local tiers = ns.Data.streakTiers
    local rows = {}
    for i, t in ipairs(tiers) do
        local nextFrom = tiers[i + 1] and tiers[i + 1].from
        local range = nextFrom and ("%d-%d"):format(t.from, nextFrom - 1) or ("ab %d"):format(t.from)
        local active = c.streak >= t.from and (not nextFrom or c.streak < nextFrom)
        rows[#rows + 1] = {
            icon = ns.CategoryIcon("Ohne Tod"), desaturate = not active, highlight = active,
            title = ("Jede Stufe ohne Tod bei Serie %s"):format(range),
            sub = "Für jede neue Stufe, solange du seit dem letzten Tod nicht gestorben bist." ..
                (active and "  |cff00ff00(deine aktuelle Serie)|r" or ""),
            right = ("|cffffd100+%d|r"):format(t.points), right2 = "pro Stufe",
            tooltip = { "Punkte pro Stufe ohne Tod",
                ("Serie %s Stufen: +%d Punkte für jede weitere Stufe."):format(range, t.points),
                "Stirbst du, beginnt die Serie wieder bei 0. Erhaltene Punkte bleiben.",
                ("Deine Serie: %d Stufen, Rekord %d. Bisher %d Punkte."):format(c.streak, c.maxStreak, c.nodeathLevelPoints) },
        }
    end
    return rows
end

function UI:RefreshAchievements()
    local P = ns.PWF
    local c = P.char
    for _, b in ipairs(self.achFilterButtons) do
        if b.key == self.achFilter then b:Disable() else b:Enable() end
    end

    local rows = {}
    for _, cat in ipairs(P.categories) do
        if self.achFilter == "all" or self.achFilter == cat then
            local items, done, total = {}, 0, 0
            if cat == "Ohne Tod" then items = self:StreakInfoRows() end
            for _, a in ipairs(P.achievements) do
                if a.cat == cat then
                    if not a.repeatable then
                        total = total + 1
                        if c.earned[a.id] then done = done + 1 end
                    end
                    items[#items + 1] = self:AchievementRow(a)
                end
            end
            rows[#rows + 1] = { header = true, title = cat, right = total > 0 and ("%d / %d"):format(done, total) or "" }
            for _, it in ipairs(items) do rows[#rows + 1] = it end
        end
    end
    self.achList:SetData(rows)
end

-- ----------------------------------------------------------------------------
--  Seite 3: Ränge (alle Titel und was man dafür braucht)
-- ----------------------------------------------------------------------------
function UI:CreateRanksPage(page)
    local info = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    info:SetPoint("TOPLEFT", 2, -4)
    info:SetPoint("RIGHT", -2, 0)
    info:SetJustifyH("LEFT")
    info:SetText("Klassenpunkte bekommst du für Erfolge. Ab einer bestimmten Punktzahl steigst du im Rang auf. " ..
        "Wer in seiner Klasse die meisten Punkte der Gilde hat, ist Klassenmeister.")

    local holder = CreateFrame("Frame", nil, page)
    holder:SetPoint("TOPLEFT", 0, -30)
    holder:SetPoint("BOTTOMRIGHT", -24, 0)
    self.rankPageList = CreateList(holder)
    self.rankPageList.scroll:SetAllPoints()
end

function UI:RefreshRanks()
    local P = ns.PWF
    local points = P.char.points
    local cur = ns.GetRank(points)

    -- Wie viele Spieler der Gilde haben welchen Rang?
    local holders = {}
    for _, e in ipairs(P:GetRoster()) do
        local r = ns.GetRank(e.points).rank
        holders[r] = (holders[r] or 0) + 1
    end

    local rows = { { header = true, title = "Ränge / Titel", right = ("Du: %d Punkte"):format(points) } }
    for _, r in ipairs(ns.Data.ranks) do
        local reached = points >= r.points
        local status
        if r == cur then
            status = "|cff00ff00Dein aktueller Rang|r"
        elseif reached then
            status = "|cff00ff00Erreicht|r"
        else
            status = ("Dir fehlen noch |cffffffff%d|r Punkte"):format(r.points - points)
        end
        local n = holders[r.rank] or 0
        rows[#rows + 1] = {
            icon = "Interface\\Icons\\Ability_Warrior_BattleShout", desaturate = not reached, highlight = (r == cur),
            title = ("%sRang %d: %s|r"):format(reached and "|cffffd100" or "|cffbbbbbb", r.rank, r.name),
            sub = ("Benötigt: %d Klassenpunkte  -  %s"):format(r.points, status),
            right2 = n > 0 and ("%d in der Gilde"):format(n) or "",
            right = (reached and "|cffffd100" or "|cff808080") .. r.points .. "|r",
            tooltip = { ("Rang %d: %s"):format(r.rank, r.name), ("Benötigt %d Klassenpunkte."):format(r.points), status },
        }
    end
    rows[#rows + 1] = { header = true, title = "Klassenmeister" }
    rows[#rows + 1] = {
        icon = "Interface\\Icons\\INV_Misc_Head_Dragon_01",
        title = "|cffffd100Klassenmeister deiner Klasse|r",
        sub = "Benötigt: die meisten Klassenpunkte aller Gildenmitglieder deiner Klasse (mit Addon).",
        tooltip = { "Klassenmeister", "Pro Klasse gibt es einen Klassenmeister: den Spieler mit den meisten Punkten.",
            "Bei Gleichstand gewinnt, wer die Punktzahl zuerst erreicht hat.", "Übersicht im Tab 'Gilde'." },
    }
    self.rankPageList:SetData(rows)
end

-- ----------------------------------------------------------------------------
--  Seite 4: Gilde (Klassenmeister + Rangliste)
-- ----------------------------------------------------------------------------
function UI:CreateGuildPage(page)
    local sync = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
    sync:SetSize(140, 22)
    sync:SetPoint("TOPRIGHT", 0, 0)
    sync:SetText("Aktualisieren")
    sync:SetScript("OnClick", function()
        ns.Comm:RequestAll()
        ns.Print("Daten der Gilde werden angefragt ...")
    end)

    self.guildInfo = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    self.guildInfo:SetPoint("TOPLEFT", 2, -4)
    self.guildInfo:SetPoint("RIGHT", sync, "LEFT", -8, 0)
    self.guildInfo:SetJustifyH("LEFT")

    local holder = CreateFrame("Frame", nil, page)
    holder:SetPoint("TOPLEFT", 0, -30)
    holder:SetPoint("BOTTOMRIGHT", -24, 0)
    self.guildList = CreateList(holder)
    self.guildList.scroll:SetAllPoints()
end

function UI:RefreshGuild()
    local P = ns.PWF
    local roster = P:GetRoster()
    local masters = P:GetClassMasters()
    if P.inGuild then
        self.guildInfo:SetText(("Gilde %s%s|r - angezeigt werden nur Mitglieder, die das Addon haben."):format(ORANGE, P.guildName))
    else
        self.guildInfo:SetText("|cffff5555Du bist in keiner Gilde.|r Erfolge und Punkte zählen trotzdem - Rangliste und Klassenmeister brauchen eine Gilde.")
    end

    local classes, seen = {}, {}
    for _, cf in ipairs(C.CLASS_ORDER) do classes[#classes + 1] = cf; seen[cf] = true end
    for _, e in ipairs(roster) do
        if e.class and not seen[e.class] then classes[#classes + 1] = e.class; seen[e.class] = true end
    end

    local rows = { { header = true, title = "Klassenmeister" } }
    for _, cf in ipairs(classes) do
        local m = masters[cf]
        local icon = CLASS_ICON_TCOORDS and "Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes" or nil
        rows[#rows + 1] = {
            icon = icon, classFile = cf,
            title = ns.ClassColored(ns.ClassName(cf), cf) .. ":  " ..
                (m and ns.ClassColored(ns.ShortName(m.name), cf) or "|cff808080noch niemand|r"),
            sub = m and ns.RankText(m.points) or "",
            right = m and ("|cffffd100%d|r"):format(m.points) or "",
            highlight = m and m.name == P.fullName,
        }
    end

    rows[#rows + 1] = { header = true, title = "Rangliste", right = ("%d Spieler"):format(#roster) }
    for i, e in ipairs(roster) do
        local isMaster = masters[e.class] and masters[e.class].name == e.name
        rows[#rows + 1] = {
            title = ("%d.  %s%s"):format(i, ns.ClassColored(ns.ShortName(e.name), e.class),
                isMaster and "  |cffffd100(Klassenmeister)|r" or ""),
            sub = ("%s, Stufe %d  -  %s  -  %d Erfolge"):format(ns.ClassName(e.class), e.level, ns.RankText(e.points), e.ach),
            right = ("|cffffd100%d|r"):format(e.points),
            highlight = e.name == P.fullName,
        }
    end
    self.guildList:SetData(rows)

    -- Klassen-Icons zuschneiden
    for _, row in ipairs(self.guildList.rows) do
        row.icon:SetTexCoord(0, 1, 0, 1)
    end
    for i, d in ipairs(rows) do
        if d.classFile and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[d.classFile] then
            self.guildList.rows[i].icon:SetTexCoord(unpack(CLASS_ICON_TCOORDS[d.classFile]))
        end
    end
end

-- ----------------------------------------------------------------------------
--  Erfolgs-Toast (Einblendung oben in der Bildschirmmitte)
-- ----------------------------------------------------------------------------
function UI:ShowToast(title, text, icon)
    self.toastQueue = self.toastQueue or {}
    table.insert(self.toastQueue, { title, text, icon })
    if not self.toastActive then self:NextToast() end
end

function UI:NextToast()
    local item = table.remove(self.toastQueue, 1)
    if not item then
        self.toastActive = false
        return
    end
    self.toastActive = true

    local t = self.toast
    if not t then
        t = CreateFrame("Frame", nil, UIParent, BACKDROP_TMPL)
        t:SetSize(360, 64)
        t:SetPoint("TOP", 0, -140)
        t:SetFrameStrata("DIALOG")
        t:SetBackdrop(DARK_BACKDROP)
        t:SetBackdropColor(0, 0, 0, 0.85)
        t:SetBackdropBorderColor(1, 0.5, 0)
        t.icon = t:CreateTexture(nil, "ARTWORK")
        t.icon:SetSize(44, 44)
        t.icon:SetPoint("LEFT", 10, 0)
        t.head = t:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        t.head:SetPoint("TOPLEFT", t.icon, "TOPRIGHT", 10, 0)
        t.head:SetText(ORANGE .. "PW Freetrans - Erfolg errungen!|r")
        t.title = t:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        t.title:SetPoint("TOPLEFT", t.head, "BOTTOMLEFT", 0, -3)
        t.title:SetPoint("RIGHT", -10, 0)
        t.title:SetJustifyH("LEFT")
        t.text = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        t.text:SetPoint("TOPLEFT", t.title, "BOTTOMLEFT", 0, -3)
        t:SetScript("OnUpdate", function(frame)
            local left = frame.hideAt - GetTime()
            if left <= 0 then
                frame:Hide()
                UI:NextToast()
            elseif left < 1 then
                frame:SetAlpha(left)
            end
        end)
        self.toast = t
    end

    t.icon:SetTexture(item[3] or "Interface\\Icons\\Ability_Warrior_BattleShout")
    t.title:SetText(item[1])
    t.text:SetText(item[2])
    t:SetAlpha(1)
    t.hideAt = GetTime() + 4
    t:Show()
    if SOUNDKIT and SOUNDKIT.IG_QUEST_LIST_COMPLETE then PlaySound(SOUNDKIT.IG_QUEST_LIST_COMPLETE) end
end

-- ----------------------------------------------------------------------------
--  Minimap-Knopf
-- ----------------------------------------------------------------------------
function UI:CreateMinimapButton()
    local s = ns.PWF.db.settings.minimap
    local b = CreateFrame("Button", "PWFreetransMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\Icons\\Ability_Warrior_BattleShout")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -5)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    local function updatePos()
        local a = math.rad(s.angle or 210)
        b:ClearAllPoints()
        b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * 80, math.sin(a) * 80)
    end
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            s.angle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
            updatePos()
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function() UI:Toggle() end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine(ORANGE .. "PW Freetrans LoL|r")
        local c = ns.PWF.char
        GameTooltip:AddLine(("%d Klassenpunkte - %s"):format(c.points, ns.RankText(c.points)), 1, 1, 1)
        GameTooltip:AddLine("Klicken: Gildenfenster öffnen", 0.7, 0.7, 0.7)
        GameTooltip:AddLine("Ziehen: Knopf verschieben", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    updatePos()
    self.minimapButton = b
    self:UpdateMinimapButton()
end

function UI:UpdateMinimapButton()
    if self.minimapButton then
        self.minimapButton:SetShown(not ns.PWF.db.settings.minimap.hide)
    end
end

-- ----------------------------------------------------------------------------
function UI:Init()
    self:CreateMainFrame()
    self:CreateMinimapButton()
end
