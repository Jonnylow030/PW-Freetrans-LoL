-- ============================================================================
--  PW Freetrans LoL - Gildenerfolge
--  Kommunikation: tauscht Klassenpunkte unsichtbar über den Gildenkanal aus.
--
--  Nachrichten (Felder mit Tab getrennt):
--    H <proto>                                         -> "Hallo, schickt mir eure Daten"
--    S <proto> <class> <level> <points> <ach> <lastGain> -> Status eines Charakters
-- ============================================================================
local ADDON, ns = ...
local C = ns.Config

local Comm = {}
ns.Comm = Comm

local PROTO = 1
local MAX_SANE_POINTS = 100000

local SendAddonMessage = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or _G.SendAddonMessage
local RegisterPrefix = (C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix) or _G.RegisterAddonMessagePrefix

function Comm:Init()
    RegisterPrefix(C.COMM_PREFIX)
end

function Comm:Send(msg)
    if not ns.PWF.inGuild then return end
    SendAddonMessage(C.COMM_PREFIX, msg, "GUILD")
end

function Comm:SendStatus()
    local P = ns.PWF
    local c = P.char
    self:Send(table.concat({ "S", PROTO, P.classFile, P:GetLevel(), c.points, c.achCount, c.lastGain }, "\t"))
end

-- Fasst mehrere Anlässe zu einer Nachricht zusammen (schont das Nachrichtenlimit)
function Comm:ScheduleStatus(delay)
    if self.pending then return end
    self.pending = true
    C_Timer.After(delay or 3, function()
        self.pending = false
        self:SendStatus()
    end)
end

function Comm:RequestAll()
    self:Send("H\t" .. PROTO)
    self:ScheduleStatus(1)
end

function Comm:OnMessage(prefix, msg, channel, sender)
    if prefix ~= C.COMM_PREFIX or channel ~= "GUILD" or not ns.PWF.inGuild then return end
    sender = ns.NormalizeName(sender)
    if sender == ns.PWF.fullName then return end

    local cmd, proto, classFile, level, points, ach, lastGain = strsplit("\t", msg)
    if cmd == "H" then
        -- Zufällige Verzögerung, damit nicht alle gleichzeitig antworten
        self:ScheduleStatus(1 + math.random() * 5)
    elseif cmd == "S" then
        level, points = tonumber(level), tonumber(points)
        if not classFile or not level or not points or points < 0 or points > MAX_SANE_POINTS then return end
        ns.PWF:UpdateRosterEntry(sender, classFile, level, points, tonumber(ach) or 0, tonumber(lastGain) or 0)
    end
end
