# PW Freetrans LoL – Gildenerfolge

Addon für WoW Forever: Klassenerfolge → Klassenpunkte → Ränge → Klassenmeister.

## Installation
1. Den Ordner `PWFreetrans` kopieren nach
   `World of Warcraft\_classic_beta_\Interface\AddOns\`
   (nach Release ggf. anderer Ordnername).
2. Im Charakterauswahl-Bildschirm unter **AddOns** aktivieren.
   Falls „veraltet" angezeigt wird: Haken bei **Veraltete AddOns laden** setzen
   oder die Zahl hinter `## Interface:` in `PWFreetrans.toc` anpassen
   (im Spiel: `/dump select(4, GetBuildInfo())`).
3. **Wichtig für „Ohne Tod“:** Das Addon ab Stufe 1 benutzen und nie ohne Addon spielen.

## Befehle
| Befehl | Funktion |
|---|---|
| `/pwf` | Gildenfenster öffnen/schließen (oder Minimap-Knopf) |
| `/pwf sync` | Punkte aller Gildenmitglieder neu anfragen |
| `/pwf ansage` | Erfolge im Gildenchat ankündigen an/aus |
| `/pwf minimap` | Minimap-Knopf ein-/ausblenden |
| `/pwf debug` | Boss-Tode in Instanzen protokollieren |
| `/pwf log` | Protokoll anzeigen |

## Dateien
| Datei | Inhalt |
|---|---|
| `Data.lua` | Erfolge, Punkte, Ränge, Dungeons – **automatisch erzeugt**, nicht von Hand ändern |
| `Config.lua` | Gildenname, Regeln (Stufengrenzen, Duell-Abklingzeit …), Berufsnamen, Symbole |
| `Core.lua` | Erfolgs-Logik und Tracking |
| `Comm.lua` | Unsichtbarer Datenaustausch im Gildenkanal |
| `UI.lua` | Fenster, Minimap-Knopf, Einblendungen |

## Erfolge ändern
1. CSV-Dateien in `Erfolgsliste/` bearbeiten.
2. `Erfolgsliste/Ins_Addon_uebernehmen.cmd` doppelklicken → erzeugt `Data.lua` neu.
3. Den Ordner `PWFreetrans` wieder ins Spiel kopieren, im Spiel `/reload`.

Alle Gildenmitglieder müssen dieselbe Version benutzen.

### Endbosse für neue Dungeons eintragen
1. `/pwf debug` einschalten, Dungeon laufen.
2. Nach dem Endboss `/pwf log` – dort stehen Name und NPC-ID.
3. In `Erfolgsliste/dungeons.csv` eintragen und übernehmen (siehe oben).

## Gut zu wissen
- **Stufen, Berufe, ehrenhafte Siege, Spielzeit** werden beim ersten Start nachträglich gutgeschrieben.
- **Gold**: Startgold zählt als verdient, danach nur echte Einnahmen (kein Handel, keine Post von Spielern, keine Gildenbank-Abhebungen; Auktionshaus-Erlöse zählen).
- **Dungeons, Duelle, Quests, Tode, Gildenbank** zählen ab Installation.
- Punkte werden lokal berechnet und per Gildenkanal geteilt – technisch versierte Spieler
  könnten ihre Daten manipulieren. Für eine Gilde unter Freunden ist das in Ordnung.
