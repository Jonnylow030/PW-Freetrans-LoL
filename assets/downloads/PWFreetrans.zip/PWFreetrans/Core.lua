-- ============================================================================
--  PW Freetrans LoL - Gildenerfolge
--  Kern: Datenbank, Erfolge aus Data.lua, Fortschritts-Tracking, Ränge.
-- ============================================================================
local ADDON, ns = ...
local C = ns.Config

local PWF = CreateFrame("Frame")
ns.PWF = PWF
_G.PWFreetrans = PWF

PWF.achievements = {}
PWF.achById = {}
PWF.categories = {}
PWF.recentKills = {}
PWF.lastDungeonDone = {}

local SECONDS_PER_HOUR = 3600

-- ----------------------------------------------------------------------------
--  Hilfsfunktionen
-- ----------------------------------------------------------------------------
local function Print(msg, ...)
    if select("#", ...) > 0 then msg = msg:format(...) end
    DEFAULT_CHAT_FRAME:AddMessage("|cffff8000[PW Freetrans]|r " .. msg)
end
ns.Print = Print

function ns.ServerTime()
    return GetServerTime and GetServerTime() or time()
end

function ns.FormatGold(copper)
    copper = math.floor(copper or 0)
    if GetCoinTextureString then return GetCoinTextureString(copper) end
    return ("%dg %ds %dc"):format(math.floor(copper / 10000), math.floor(copper % 10000 / 100), copper % 100)
end

function ns.PlayerFullName()
    local name, realm = UnitFullName("player")
    if not realm or realm == "" then realm = GetNormalizedRealmName and GetNormalizedRealmName() end
    if realm and realm ~= "" then return name .. "-" .. realm end
    return name
end

function ns.NormalizeName(name)
    if not name then return nil end
    if not name:find("-", 1, true) then
        local realm = GetNormalizedRealmName and GetNormalizedRealmName()
        if realm and realm ~= "" then name = name .. "-" .. realm end
    end
    return name
end

function ns.ShortName(name)
    if Ambiguate then return Ambiguate(name, "guild") end
    return (name:gsub("%-.*$", ""))
end

function ns.ClassName(classFile)
    return (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[classFile]) or classFile or "?"
end

function ns.ClassColored(text, classFile)
    local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
    if not c then return text end
    local hex = c.colorStr or ("ff%02x%02x%02x"):format(c.r * 255, c.g * 255, c.b * 255)
    return "|c" .. hex .. text .. "|r"
end

function ns.CategoryIcon(cat)
    return C.CATEGORY_ICONS[cat] or C.DEFAULT_ICON
end

-- Liefert aktuellen Rang und nächsten Rang (oder nil) für eine Punktzahl.
function ns.GetRank(points)
    local ranks = ns.Data.ranks
    local cur, nxt = ranks[1], nil
    for i, r in ipairs(ranks) do
        if (points or 0) >= r.points then
            cur, nxt = r, ranks[i + 1]
        else
            break
        end
    end
    return cur, nxt
end

function ns.RankText(points)
    local r = ns.GetRank(points)
    return ("Rang %d: %s"):format(r.rank, r.name)
end

local function SafeRegister(frame, event)
    return pcall(frame.RegisterEvent, frame, event)
end

-- Debug-Protokoll (bleibt gespeichert, /pwf log zeigt es an)
function PWF:Log(msg, ...)
    if select("#", ...) > 0 then msg = msg:format(...) end
    local log = PWFreetransDB.log
    log[#log + 1] = date("%d.%m. %H:%M") .. "  " .. msg
    while #log > 200 do table.remove(log, 1) end
    if PWFreetransDB.settings.debug then Print("|cff999999[Debug]|r " .. msg) end
end

-- ----------------------------------------------------------------------------
--  Datenbank
-- ----------------------------------------------------------------------------
function PWF:InitDB()
    PWFreetransDB = PWFreetransDB or {}
    local db = PWFreetransDB
    db.roster = db.roster or {}
    db.log = db.log or {}
    db.settings = db.settings or {}
    local s = db.settings
    if s.announce == nil then s.announce = C.ANNOUNCE_IN_GUILD_DEFAULT end
    if s.debug == nil then s.debug = false end
    s.minimap = s.minimap or { angle = 210, hide = false }

    PWFreetransCharDB = PWFreetransCharDB or {}
    local c = PWFreetransCharDB
    local defaults = {
        earned = {},           -- [achId] = Zeitstempel
        repeatCounts = {},     -- [achId] = wie oft ein wiederholbarer Erfolg schon gezählt wurde
        profs = {},            -- [profKey] = höchster Skill
        primaryProfs = {},     -- die ersten zwei Hauptberufe (nur die zählen)
        dungeons = {},         -- [dungeonKey] = Anzahl Abschlüsse
        quests = {},           -- [questID] = { lvl, elig, grouped } für Solo-Gruppenquests
        duelLast = {},         -- [Gegner] = Zeitstempel des letzten gezählten Siegs
        guildDuelDay = {},     -- [Gildenmitglied] = Datum des letzten gezählten Siegs
        goldEarned = 0, gbankNet = 0,
        duels = 0, guildDuels = 0, hk = 0, deaths = 0,
        guildRuns = 0, soloElite = 0,
        streak = 0, maxStreak = 0, nodeathLevelPoints = 0,
        points = 0, achCount = 0, lastGain = 0, level = 0,
    }
    for k, v in pairs(defaults) do
        if c[k] == nil then c[k] = v end
    end

    self.db = db
    self.char = c
end

-- Nachschlagetabellen für Berufe und Bosse
function PWF:BuildLookups()
    ns.profByName, ns.profByKey = {}, {}
    for _, p in ipairs(C.PROFESSIONS) do
        ns.profByKey[p.key] = p
        for _, n in ipairs(p.names) do ns.profByName[n] = p.key end
    end
    ns.bossByNpc, ns.bossByName, ns.dungeonByKey = {}, {}, {}
    for _, d in ipairs(ns.Data.dungeons) do
        ns.dungeonByKey[d.key] = d
        for _, id in ipairs(d.npcIds or {}) do ns.bossByNpc[id] = d.key end
        for _, n in ipairs(d.bosses or {}) do ns.bossByName[n:lower()] = d.key end
    end
end

-- ----------------------------------------------------------------------------
--  Erfolge aus Data.lua erzeugen (für die Klasse des aktuellen Charakters)
-- ----------------------------------------------------------------------------
local COPPER_TYPES = { gold = true, guildbank_gold = true }

function PWF:BuildAchievements()
    wipe(self.achievements)
    wipe(self.achById)
    wipe(self.categories)
    local seenCat = {}
    local cls = self.className
    local profsDone = false

    local function add(a)
        a.name = a.name:gsub("{Klasse}", cls)
        self.achievements[#self.achievements + 1] = a
        self.achById[a.id] = a
        if not seenCat[a.cat] then
            seenCat[a.cat] = true
            self.categories[#self.categories + 1] = a.cat
        end
    end

    for _, row in ipairs(ns.Data.achievements) do
        local base = {
            id = row.id, cat = row.cat, type = row.type, points = row.points,
            value = COPPER_TYPES[row.type] and row.threshold * 10000 or row.threshold,
            repeatable = row.repeatable, name = row.name, desc = row.desc, rule = row.rule,
        }
        if row.type == "profession" then
            -- Alle Berufszeilen auf einmal einfügen, sortiert nach Beruf (Alchemie 50, 100 ... dann Schmiedekunst ...)
            -- "ALLE" = eine Erfolgsreihe pro Beruf, sonst nur der genannte Beruf
            if not profsDone then
                profsDone = true
                for _, p in ipairs(C.PROFESSIONS) do
                    for _, prow in ipairs(ns.Data.achievements) do
                        if prow.type == "profession" and (prow.target == "ALLE" or ns.profByName[prow.target] == p.key) then
                            add({
                                id = prow.id .. "_" .. p.key, cat = prow.cat, type = prow.type, key = p.key,
                                points = prow.points, value = prow.threshold, repeatable = false,
                                name = prow.name:gsub("%[Beruf%]", p.names[1]),
                                desc = prow.desc:gsub("einen Beruf", p.names[1]), rule = prow.rule,
                            })
                        end
                    end
                end
            end
        else
            if row.type == "dungeon" then
                base.key = row.target
                local d = ns.dungeonByKey[row.target]
                if d and #d.npcIds + #d.bosses == 0 then
                    base.desc = base.desc .. " |cffff5555(Endboss noch nicht hinterlegt)|r"
                end
            end
            if row.repeatable then
                local lo, hi = (row.target or ""):match("^(%d+)%-(%d+)$")
                base.lo, base.hi = tonumber(lo) or 0, tonumber(hi) or math.huge
                base.step = row.threshold > 0 and row.threshold or 1
            end
            add(base)
        end
    end

    self.maxPoints = 0
    for _, a in ipairs(self.achievements) do
        if not a.repeatable then self.maxPoints = self.maxPoints + a.points end
    end
end

function PWF:GetLevel()
    return math.max(UnitLevel("player") or 0, self.char.level or 0)
end

-- Spielzeit in Stunden (letzte /played-Abfrage + seitdem vergangene Zeit)
function PWF:PlayedHours()
    local c = self.char
    if not c.playedSeconds then return 0 end
    local extra = self.playedAt and (GetTime() - self.playedAt) or 0
    return (c.playedSeconds + extra) / SECONDS_PER_HOUR
end

-- Zählt ein Beruf? Nebenberufe immer, Hauptberufe nur die ersten zwei.
function PWF:ProfSkill(key)
    local p = ns.profByKey[key]
    if not p then return 0 end
    if not p.secondary and not tContains(self.char.primaryProfs, key) then return 0 end
    return self.char.profs[key] or 0
end

function PWF:LegendaryPossible()
    local c = self.char
    return c.trackStartLevel == 1 and not c.everDied and not c.untracked
end

-- Aktueller Wert je Erfolgstyp; Erfolg erreicht, wenn Wert >= Schwelle
local CURRENT = {
    level               = function(P) return P:GetLevel() end,
    gold                = function(P) return P.char.goldEarned end,
    dungeon             = function(P, a) return P.char.dungeons[a.key] or 0 end,
    profession          = function(P, a) return P:ProfSkill(a.key) end,
    duel_won            = function(P) return P.char.duels end,
    duel_won_guild      = function(P) return P.char.guildDuels end,
    honor_kills         = function(P) return P.char.hk end,
    nodeath_streak      = function(P) return P.char.maxStreak end,
    nodeath_full        = function(P) return P:LegendaryPossible() and P:GetLevel() or 0 end,
    guild_group_dungeon = function(P) return P.char.guildRuns end,
    guildbank_gold      = function(P) return P.char.gbankNet end,
    solo_elite_quest    = function(P) return P.char.soloElite end,
    played_hours        = function(P) return P:PlayedHours() end,
    death_count         = function(P) return P.char.deaths end,
}

function PWF:GetCurrent(a)
    local f = CURRENT[a.type]
    return f and f(self, a) or 0
end

function PWF:IsAchieved(a)
    return self:GetCurrent(a) >= a.value
end

-- Wie oft hat ein wiederholbarer Erfolg schon gezählt? (z. B. je 10 Std. im Bereich lo-hi)
function PWF:RepeatCount(a)
    local cur = self:GetCurrent(a)
    if cur <= a.lo then return 0 end
    return math.floor((math.min(cur, a.hi) - a.lo) / a.step)
end

-- Fortschrittstext für noch nicht erreichte Erfolge
function PWF:GetProgressText(a)
    local cur = self:GetCurrent(a)
    if a.repeatable then
        local n = self:RepeatCount(a)
        return ("%dx = %d Pkt."):format(n, n * a.points)
    elseif COPPER_TYPES[a.type] then
        return ("%dg / %dg"):format(math.floor(cur / 10000), a.value / 10000)
    elseif a.type == "dungeon" then
        return "offen"
    elseif a.type == "nodeath_full" then
        return self:LegendaryPossible() and ("Stufe %d / %d"):format(self:GetLevel(), a.value) or "verwirkt"
    end
    return ("%d / %d"):format(math.floor(cur), a.value)
end

function PWF:RecalcPoints()
    local c = self.char
    local total, count = 0, 0
    for id in pairs(c.earned) do
        local a = self.achById[id]
        if a then
            total = total + a.points
            count = count + 1
        end
    end
    for _, a in ipairs(self.achievements) do
        if a.repeatable then total = total + (c.repeatCounts[a.id] or 0) * a.points end
    end
    total = total + c.nodeathLevelPoints
    if total > c.points then c.lastGain = ns.ServerTime() end
    c.points = total
    c.achCount = count
end

-- Prüft alle Erfolge. silent = true -> keine Einzel-Meldungen (z. B. beim ersten Start)
function PWF:CheckAchievements(silent)
    local c = self.char
    local now = ns.ServerTime()
    local newly, repeatGain = {}, {}

    for _, a in ipairs(self.achievements) do
        if a.repeatable then
            local n = self:RepeatCount(a)
            local old = c.repeatCounts[a.id] or 0
            if n > old then
                c.repeatCounts[a.id] = n
                repeatGain[#repeatGain + 1] = { a = a, pts = (n - old) * a.points }
            end
        elseif not c.earned[a.id] and self:IsAchieved(a) then
            c.earned[a.id] = now
            newly[#newly + 1] = a
        end
    end

    local oldPoints = c.points
    local oldRank = ns.GetRank(oldPoints)
    self:RecalcPoints()
    if c.points == oldPoints and #newly == 0 then return end
    local newRank = ns.GetRank(c.points)

    if silent then
        if c.points > oldPoints then
            Print("%d Erfolge nachträglich gutgeschrieben (+%d Punkte).", #newly, c.points - oldPoints)
        end
    else
        for _, a in ipairs(newly) do self:AnnounceAchievement(a) end
        for _, g in ipairs(repeatGain) do
            Print("%s: |cff00ff00+%d Punkte|r", g.a.name, g.pts)
            if ns.UI then ns.UI:ShowToast(g.a.name, ("+%d Klassenpunkte"):format(g.pts), ns.CategoryIcon(g.a.cat)) end
        end
    end

    if newRank.rank > oldRank.rank then
        Print("|cffffd100Neuer Rang erreicht: Rang %d - %s!|r", newRank.rank, newRank.name)
        if ns.UI then ns.UI:ShowToast("Neuer Rang!", ("Rang %d: %s"):format(newRank.rank, newRank.name), "Interface\\Icons\\Ability_Warrior_BattleShout") end
        if self.db.settings.announce and self.inGuild and not silent then
            SendChatMessage(("[PW Freetrans] %s hat Rang %d erreicht: %s!"):format(self.className, newRank.rank, newRank.name), "GUILD")
        end
    end

    self:OnProgressChanged()
end

function PWF:AnnounceAchievement(a)
    Print("Erfolg errungen: |cff00ff00%s|r (+%d Punkte)", a.name, a.points)
    if ns.UI then ns.UI:ShowToast(a.name, ("+%d Klassenpunkte"):format(a.points), ns.CategoryIcon(a.cat)) end
    if self.db.settings.announce and self.inGuild then
        SendChatMessage(("[PW Freetrans] Erfolg: %s (+%d Punkte, gesamt %d)"):format(a.name, a.points, self.char.points), "GUILD")
    end
end

function PWF:OnProgressChanged()
    self:UpdateOwnRosterEntry()
    if ns.Comm then ns.Comm:ScheduleStatus(3) end
    if ns.UI then ns.UI:Refresh() end
end

-- ----------------------------------------------------------------------------
--  Gold: verdient (ohne Handel, Spieler-Post, Gildenbank) und Gildenbank-Spenden
-- ----------------------------------------------------------------------------
function PWF:IgnoreMoneyGain()
    local now = GetTime()
    if self.inTrade or now < (self.tradeGrace or 0) then return true end
    if self.atGuildBank or now < (self.guildBankGrace or 0) then return true end
    if self.atMail then
        -- Post: nur Auktionshaus-Erlöse zählen
        return not (self.mailFromAH and now < (self.mailFromAHUntil or 0))
    end
    return false
end

function PWF:UpdateMoney()
    local c = self.char
    local money = GetMoney()
    local last = c.lastMoney
    c.lastMoney = money
    if not last or money == last then return end
    local diff = money - last

    if self.atGuildBank or GetTime() < (self.guildBankGrace or 0) then
        -- Einzahlung erhöht, Abhebung verringert die Netto-Spende
        c.gbankNet = math.max(0, c.gbankNet - diff)
    end
    if diff > 0 and not self:IgnoreMoneyGain() then
        c.goldEarned = c.goldEarned + diff
    end
end

function PWF:OnMoneyChanged()
    self:UpdateMoney()
    self:CheckAchievements(false)
end

function PWF:HookMail()
    local function onTake(index)
        local invoiceType = GetInboxInvoiceInfo and GetInboxInvoiceInfo(index)
        PWF.mailFromAH = (invoiceType == "seller")
        PWF.mailFromAHUntil = GetTime() + 5
    end
    if TakeInboxMoney then hooksecurefunc("TakeInboxMoney", onTake) end
    if AutoLootMailItem then hooksecurefunc("AutoLootMailItem", onTake) end
end

-- ----------------------------------------------------------------------------
--  Berufe
-- ----------------------------------------------------------------------------
function PWF:ScanProfessions()
    local c = self.char
    local function set(name, rank)
        local key = name and ns.profByName[name]
        if not key or not rank or rank <= 0 then return end
        local p = ns.profByKey[key]
        if not p.secondary and not tContains(c.primaryProfs, key) and #c.primaryProfs < 2 then
            table.insert(c.primaryProfs, key)
        end
        if rank > (c.profs[key] or 0) then c.profs[key] = rank end
    end

    if GetProfessions and GetProfessionInfo then
        local list = { GetProfessions() }
        for i = 1, 6 do
            if list[i] then
                local name, _, rank = GetProfessionInfo(list[i])
                set(name, rank)
            end
        end
    elseif GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local name, isHeader, _, rank = GetSkillLineInfo(i)
            if not isHeader then set(name, rank) end
        end
    end
end

function PWF:OnSkillsChanged()
    if self.skillTimer then return end
    self.skillTimer = true
    C_Timer.After(0.5, function()
        self.skillTimer = nil
        self:ScanProfessions()
        self:CheckAchievements(false)
    end)
end

-- ----------------------------------------------------------------------------
--  Stufen & "Ohne Tod"
-- ----------------------------------------------------------------------------
function ns.StreakPoints(streak)
    local pts = 0
    for _, t in ipairs(ns.Data.streakTiers) do
        if streak >= t.from then pts = t.points end
    end
    return pts
end

function PWF:OnLevelChanged(newLevel)
    local c = self.char
    local last = c.lastLevel or newLevel
    local gained = 0
    for _ = last + 1, newLevel do
        c.streak = c.streak + 1
        local p = ns.StreakPoints(c.streak)
        c.nodeathLevelPoints = c.nodeathLevelPoints + p
        gained = gained + p
    end
    c.maxStreak = math.max(c.maxStreak, c.streak)
    c.lastLevel = math.max(last, newLevel)
    c.level = math.max(c.level or 0, newLevel)
    if gained > 0 then
        Print("Stufe ohne Tod! Serie: |cffffd100%d|r Stufen, |cff00ff00+%d Punkte|r", c.streak, gained)
    end
    self:CheckAchievements(false)
end

function PWF:OnPlayerDead()
    local c = self.char
    c.deaths = c.deaths + 1
    if c.streak >= 3 then
        Print("|cffff5555Serie ohne Tod beendet|r (%d Stufen).", c.streak)
    end
    if not c.everDied and c.trackStartLevel == 1 then
        Print("|cffff5555Der legendäre Bonus (Stufe 60 ohne Tod) ist verwirkt.|r")
    end
    c.streak = 0
    c.everDied = true
    self:CheckAchievements(false)
end

-- Beim Einloggen: Ist die Stufe gestiegen, während das Addon aus war?
function PWF:CheckUntrackedLevels()
    local c = self.char
    local lvl = UnitLevel("player")
    if c.lastLevel and lvl > c.lastLevel then
        Print("|cffff5555Es wurde ohne Addon gespielt (Stufe %d -> %d). Die Serie ohne Tod beginnt neu, der legendäre Bonus entfällt.|r",
            c.lastLevel, lvl)
        c.streak = 0
        c.untracked = true
        c.lastLevel = lvl
    end
end

-- ----------------------------------------------------------------------------
--  Dungeons & Gildenruns
-- ----------------------------------------------------------------------------
function PWF:UpdateInstanceState()
    local inInstance, itype = IsInInstance()
    self.inDungeon = inInstance and (itype == "party" or itype == "raid")
    if self.inDungeon then
        self.instanceName = GetInstanceInfo()
        self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    else
        self.instanceName = nil
        self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
        wipe(self.recentKills)
    end
end

function PWF:OnCombatLog()
    local _, sub, _, _, _, _, _, destGUID, destName = CombatLogGetCurrentEventInfo()
    if sub ~= "UNIT_DIED" or not destGUID or self.recentKills[destGUID] then return end
    local unitType, _, _, _, _, npcId = strsplit("-", destGUID)
    if unitType ~= "Creature" and unitType ~= "Vehicle" then return end
    npcId = tonumber(npcId)

    local key = (npcId and ns.bossByNpc[npcId]) or (destName and ns.bossByName[destName:lower()])
    if self.db.settings.debug then
        self:Log("Tod in %s: %s (NPC-ID %s)%s", self.instanceName or "?", destName or "?", tostring(npcId),
            key and (" -> Endboss von " .. key) or "")
    end
    if key then
        self.recentKills[destGUID] = true
        self:CompleteDungeon(key, destName)
    end
end

function PWF:OnEncounterEnd(encounterID, encounterName, _, _, success)
    self:Log("Boss-Encounter in %s: %s (Encounter-ID %s, %s)", self.instanceName or "?", tostring(encounterName),
        tostring(encounterID), success == 1 and "besiegt" or "fehlgeschlagen")
    if success == 1 and encounterName then
        local key = ns.bossByName[encounterName:lower()]
        if key then self:CompleteDungeon(key, encounterName) end
    end
end

function PWF:CountGuildInGroup()
    if not self.inGuild then return 0 end
    local n = 1
    if IsInRaid() then
        for i = 1, GetNumGroupMembers() do
            local u = "raid" .. i
            if not UnitIsUnit(u, "player") and UnitIsInMyGuild(u) then n = n + 1 end
        end
    else
        for i = 1, GetNumSubgroupMembers() do
            if UnitIsInMyGuild("party" .. i) then n = n + 1 end
        end
    end
    return n
end

function PWF:CompleteDungeon(key, bossName)
    -- Kampflog und Encounter-Event können für denselben Kill feuern -> 2 Min. Sperre
    local now = GetTime()
    if self.lastDungeonDone[key] and now - self.lastDungeonDone[key] < 120 then return end
    self.lastDungeonDone[key] = now

    local c = self.char
    local d = ns.dungeonByKey[key]
    local dname = d and d.name or key
    self:Log("Endboss besiegt: %s (%s)", key, bossName or "?")

    -- Gildenrun zählt unabhängig von der Stufe
    local guildies = self:CountGuildInGroup()
    if guildies >= C.GUILD_RUN_MIN_MEMBERS then
        c.guildRuns = c.guildRuns + 1
        Print("Gildenrun abgeschlossen (%d Gildenmitglieder) - insgesamt %d.", guildies, c.guildRuns)
    end

    if d and self:GetLevel() > d.max + C.DUNGEON_MAX_LEVEL_OVER then
        Print("%s besiegt - deine Stufe ist zu hoch (max. %d), zählt nicht für den Dungeon-Erfolg.",
            dname, d.max + C.DUNGEON_MAX_LEVEL_OVER)
    else
        c.dungeons[key] = (c.dungeons[key] or 0) + 1
        Print("Dungeon abgeschlossen: |cff00ff00%s|r (%dx) - %s besiegt.", dname, c.dungeons[key], bossName or "Endboss")
    end
    self:CheckAchievements(false)
end

-- ----------------------------------------------------------------------------
--  Duelle
-- ----------------------------------------------------------------------------
-- Wandelt einen WoW-Formatstring ("%1$s hat %2$s ...") in ein Lua-Muster um
local function FormatToPattern(fmt)
    local pat, order, i, n = "", {}, 1, 0
    while i <= #fmt do
        local a, b, num = fmt:find("^%%(%d)%$s", i)
        if a then
            n = n + 1
            order[n] = tonumber(num)
            pat = pat .. "(.-)"
            i = b + 1
        elseif fmt:find("^%%s", i) then
            n = n + 1
            order[n] = n
            pat = pat .. "(.-)"
            i = i + 2
        else
            local ch = fmt:sub(i, i)
            if ch:find("[%^%$%(%)%%%.%[%]%*%+%-%?]") then ch = "%" .. ch end
            pat = pat .. ch
            i = i + 1
        end
    end
    return "^" .. pat .. "$", order
end

local function MatchFormat(msg, pat, order)
    local caps = { msg:match(pat) }
    if not caps[1] then return nil end
    local args = {}
    for k, pos in ipairs(order) do args[pos] = caps[k] end
    return args[1], args[2]
end

function PWF:InitDuelPatterns()
    if DUEL_WINNER_KNOCKOUT then
        self.duelPattern, self.duelOrder = FormatToPattern(DUEL_WINNER_KNOCKOUT)
    end
end

function PWF:FindUnitLevel(name)
    local short = ns.ShortName(name)
    for _, u in ipairs({ "target", "mouseover", "party1", "party2", "party3", "party4" }) do
        if UnitExists(u) and UnitName(u) == short then return UnitLevel(u) end
    end
end

function PWF:OnSystemMessage(msg)
    if not self.duelPattern then return end
    local winner, loser = MatchFormat(msg, self.duelPattern, self.duelOrder)
    -- Nur echte Siege: Flucht/Aufgeben erzeugt eine andere Systemnachricht
    if winner and loser and winner == UnitName("player") then self:OnDuelWon(loser) end
end

function PWF:OnDuelWon(loser)
    local c = self.char
    local key = ns.NormalizeName(loser)
    local now = ns.ServerTime()

    local lvl = self:FindUnitLevel(loser)
    if lvl and lvl > 0 and lvl < self:GetLevel() - C.DUEL_MAX_LEVEL_BELOW then
        Print("Duell gegen %s gewonnen - Gegner ist zu niedrig (Stufe %d), zählt nicht.", ns.ShortName(loser), lvl)
        return
    end

    local counted = false
    local last = c.duelLast[key]
    if last and now - last < C.DUEL_COOLDOWN then
        Print("Duell gegen %s gewonnen - zählt erst wieder in %d Min.", ns.ShortName(loser),
            math.ceil((C.DUEL_COOLDOWN - (now - last)) / 60))
    else
        c.duels = c.duels + 1
        c.duelLast[key] = now
        counted = true
    end

    if self.guildMembers and self.guildMembers[key] then
        local today = date("%Y-%m-%d", now)
        if c.guildDuelDay[key] ~= today then
            c.guildDuels = c.guildDuels + 1
            c.guildDuelDay[key] = today
            counted = true
            Print("Gildenduell gegen %s gewonnen! (%d insgesamt)", ns.ShortName(loser), c.guildDuels)
        end
    end

    -- Alte Einträge aufräumen
    for name, t in pairs(c.duelLast) do
        if now - t > 86400 then c.duelLast[name] = nil end
    end
    if counted then self:CheckAchievements(false) end
end

-- ----------------------------------------------------------------------------
--  Ehrenhafte Siege
-- ----------------------------------------------------------------------------
function PWF:UpdateHonorKills()
    if not GetPVPLifetimeStats then return end
    local hk = GetPVPLifetimeStats()
    if hk and hk > self.char.hk then self.char.hk = hk end
end

-- ----------------------------------------------------------------------------
--  Solo-Gruppenquests
-- ----------------------------------------------------------------------------
local EXCLUDED_QUEST_TAGS = { [41] = true, [62] = true, [81] = true, [88] = true, [89] = true } -- PvP, Raid, Dungeon ...

local function QuestTag(questID)
    if C_QuestLog and C_QuestLog.GetQuestTagInfo then
        local info = C_QuestLog.GetQuestTagInfo(questID)
        return info and info.tagID
    elseif GetQuestTagInfo then
        return (GetQuestTagInfo(questID))
    end
end

function PWF:ScanQuestLog()
    if not GetQuestLogTitle or not GetNumQuestLogEntries then return end
    local tracked = self.char.quests
    local seen = {}
    local numEntries = GetNumQuestLogEntries()
    for i = 1, numEntries do
        local _, level, suggestedGroup, isHeader, _, _, _, questID = GetQuestLogTitle(i)
        if not isHeader and questID then
            seen[questID] = true
            if not tracked[questID] then
                local tag = QuestTag(questID)
                local elig = ((tonumber(suggestedGroup) or 0) >= 2 or tag == 1) and not EXCLUDED_QUEST_TAGS[tag]
                -- Quests, die ohne Addon angenommen wurden, gelten vorsichtshalber als "in Gruppe"
                tracked[questID] = { lvl = level or 0, elig = elig and true or false,
                    grouped = (not self.questScanReady) or IsInGroup() }
            end
        end
    end
    -- Nicht mehr im Questlog (abgebrochen) -> nach 10 Min. vergessen.
    -- Bei leerem Log (direkt nach dem Login oft noch nicht geladen) nichts löschen.
    if numEntries > 0 then
        local now = time()
        for id, t in pairs(tracked) do
            if seen[id] then
                t.missingSince = nil
            else
                t.missingSince = t.missingSince or now
                if now - t.missingSince > 600 then tracked[id] = nil end
            end
        end
    end
end

function PWF:OnGroupChanged()
    if IsInGroup() then
        for _, t in pairs(self.char.quests) do t.grouped = true end
    end
end

function PWF:OnQuestTurnedIn(questID)
    local t = self.char.quests[questID]
    self.char.quests[questID] = nil
    if not t or not t.elig then return end
    if t.grouped or IsInGroup() then return end
    if t.lvl < self:GetLevel() - C.SOLO_QUEST_MAX_LEVEL_BELOW then
        Print("Gruppenquest allein geschafft - aber zu niedrige Stufe, zählt nicht.")
        return
    end
    self.char.soloElite = self.char.soloElite + 1
    Print("|cff00ff00Gruppenquest allein geschafft!|r (%d insgesamt)", self.char.soloElite)
    self:CheckAchievements(false)
end

-- ----------------------------------------------------------------------------
--  Spielzeit (/played wird unsichtbar abgefragt)
-- ----------------------------------------------------------------------------
function PWF:HookPlayedChat()
    if type(ChatFrame_DisplayTimePlayed) == "function" then
        local orig = ChatFrame_DisplayTimePlayed
        ChatFrame_DisplayTimePlayed = function(...)
            if PWF.suppressPlayed then return end
            return orig(...)
        end
    end
end

function PWF:RequestPlayed()
    if not RequestTimePlayed then return end
    self.suppressPlayed = true
    RequestTimePlayed()
    C_Timer.After(3, function() PWF.suppressPlayed = false end)
end

function PWF:OnTimePlayed(total)
    if not total then return end
    self.char.playedSeconds = total
    self.playedAt = GetTime()
    self:CheckAchievements(not self.char.playedInit)
    self.char.playedInit = true
end

-- ----------------------------------------------------------------------------
--  Gilde & Rangliste
-- ----------------------------------------------------------------------------
-- Das Addon funktioniert in jeder Gilde (und ohne Gilde für sich allein).
-- Rangliste, Klassenmeister und Datenaustausch gelten innerhalb der eigenen Gilde.
function PWF:UpdateGuildStatus()
    local guildName = GetGuildInfo("player")
    if guildName == self.guildName then return end
    self.guildName = guildName
    self.inGuild = guildName ~= nil
    self.guildMembers = nil
    if self.inGuild then
        self:UpdateOwnRosterEntry()
        if ns.Comm then ns.Comm:RequestAll() end
    end
    if ns.UI then ns.UI:Refresh() end
end

function PWF:UpdateGuildMembers()
    if not self.inGuild or not GetNumGuildMembers then return end
    local n = GetNumGuildMembers()
    if not n or n == 0 then return end
    local set = {}
    for i = 1, n do
        local name = GetGuildRosterInfo(i)
        if name then set[ns.NormalizeName(name)] = true end
    end
    self.guildMembers = set
    if ns.UI then ns.UI:Refresh() end
end

function PWF:UpdateRosterEntry(name, classFile, level, points, ach, lastGain)
    local e = self.db.roster[name] or {}
    e.class, e.level, e.points, e.ach, e.lastGain = classFile, level, points, ach, lastGain
    e.seen = ns.ServerTime()
    self.db.roster[name] = e
    if ns.UI then ns.UI:Refresh() end
end

function PWF:UpdateOwnRosterEntry()
    if not self.fullName then return end
    self:UpdateRosterEntry(self.fullName, self.classFile, self:GetLevel(), self.char.points, self.char.achCount, self.char.lastGain)
end

-- Rangliste: aktuelle Gildenmitglieder (sobald die Mitgliederliste geladen ist);
-- ohne Gilde nur der eigene Charakter
function PWF:GetRoster()
    local list = {}
    for name, e in pairs(self.db.roster) do
        local show
        if not self.inGuild then
            show = (name == self.fullName)
        else
            show = name == self.fullName or not self.guildMembers or self.guildMembers[name]
        end
        if show then
            list[#list + 1] = {
                name = name, class = e.class, level = e.level or 0, points = e.points or 0,
                ach = e.ach or 0, lastGain = e.lastGain or 0,
            }
        end
    end
    table.sort(list, function(a, b)
        if a.points ~= b.points then return a.points > b.points end
        if a.lastGain ~= b.lastGain then return a.lastGain < b.lastGain end -- wer zuerst da war, gewinnt
        return a.name < b.name
    end)
    return list
end

-- Klassenmeister = Spieler mit den meisten Punkten seiner Klasse
function PWF:GetClassMasters()
    local masters = {}
    for _, e in ipairs(self:GetRoster()) do -- bereits sortiert
        if e.points > 0 and e.class and not masters[e.class] then masters[e.class] = e end
    end
    return masters
end

-- ----------------------------------------------------------------------------
--  Slash-Befehle
-- ----------------------------------------------------------------------------
SLASH_PWFREETRANS1 = "/pwf"
SLASH_PWFREETRANS2 = "/freetrans"
SlashCmdList["PWFREETRANS"] = function(msg)
    local cmd = (msg or ""):lower():match("^%s*(%S*)")
    local s = PWF.db.settings
    if cmd == "" then
        ns.UI:Toggle()
    elseif cmd == "sync" then
        ns.Comm:RequestAll()
        Print("Daten der Gilde werden angefragt ...")
    elseif cmd == "ansage" then
        s.announce = not s.announce
        Print("Ankündigung im Gildenchat: %s", s.announce and "|cff00ff00an|r" or "|cffff5555aus|r")
    elseif cmd == "debug" then
        s.debug = not s.debug
        Print("Debug-Modus: %s", s.debug and "|cff00ff00an|r (Boss-Tode in Instanzen werden protokolliert)" or "|cffff5555aus|r")
    elseif cmd == "log" then
        local log = PWF.db.log
        Print("Letzte Einträge im Protokoll:")
        for i = math.max(1, #log - 19), #log do DEFAULT_CHAT_FRAME:AddMessage("  " .. log[i]) end
    elseif cmd == "minimap" then
        s.minimap.hide = not s.minimap.hide
        ns.UI:UpdateMinimapButton()
    else
        Print("Befehle:")
        DEFAULT_CHAT_FRAME:AddMessage("  /pwf - Gildenfenster öffnen/schließen")
        DEFAULT_CHAT_FRAME:AddMessage("  /pwf sync - Punkte aller Gildenmitglieder neu anfragen")
        DEFAULT_CHAT_FRAME:AddMessage("  /pwf ansage - Erfolge im Gildenchat ankündigen an/aus")
        DEFAULT_CHAT_FRAME:AddMessage("  /pwf minimap - Minimap-Knopf ein-/ausblenden")
        DEFAULT_CHAT_FRAME:AddMessage("  /pwf debug - Boss-Tode in Instanzen protokollieren")
        DEFAULT_CHAT_FRAME:AddMessage("  /pwf log - Protokoll anzeigen (NPC-IDs für neue Dungeons)")
    end
end

-- ----------------------------------------------------------------------------
--  Events
-- ----------------------------------------------------------------------------
PWF:RegisterEvent("ADDON_LOADED")
PWF:RegisterEvent("PLAYER_LOGIN")
PWF:SetScript("OnEvent", function(self, event, ...)
    if self[event] then self[event](self, ...) end
end)

function PWF:ADDON_LOADED(name)
    if name ~= ADDON then return end
    self:UnregisterEvent("ADDON_LOADED")
    self:InitDB()
    self:BuildLookups()
end

function PWF:PLAYER_LOGIN()
    local className, classFile = UnitClass("player")
    self.className, self.classFile = className, classFile
    self.fullName = ns.PlayerFullName()
    self:BuildAchievements()
    self:RecalcPoints()
    self:InitDuelPatterns()
    self:HookMail()
    self:HookPlayedChat()

    ns.Comm:Init()
    ns.UI:Init()

    for _, ev in ipairs({
        "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "PLAYER_LEVEL_UP", "PLAYER_MONEY", "PLAYER_DEAD",
        "SKILL_LINES_CHANGED", "ENCOUNTER_END", "PLAYER_GUILD_UPDATE", "GUILD_ROSTER_UPDATE", "CHAT_MSG_ADDON",
        "CHAT_MSG_SYSTEM", "PLAYER_PVP_KILLS_CHANGED", "QUEST_LOG_UPDATE", "QUEST_TURNED_IN", "GROUP_ROSTER_UPDATE",
        "TIME_PLAYED_MSG", "TRADE_SHOW", "TRADE_CLOSED", "MAIL_SHOW", "MAIL_CLOSED",
        "GUILDBANKFRAME_OPENED", "GUILDBANKFRAME_CLOSED",
        "PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
    }) do
        SafeRegister(self, ev) -- nicht jedes Event gibt es in jeder Spielversion
    end

    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() elseif GuildRoster then GuildRoster() end
end

function PWF:PLAYER_ENTERING_WORLD()
    self:UpdateInstanceState()
    if self.started then return end
    self.started = true

    local c = self.char
    if not c.initialized then
        -- Erster Start auf diesem Charakter
        c.goldEarned = GetMoney()   -- vorhandenes Gold zählt als verdient
        c.lastMoney = GetMoney()
        c.lastLevel = UnitLevel("player")
        c.trackStartLevel = UnitLevel("player")
    end
    c.lastLevel = c.lastLevel or UnitLevel("player")
    self:CheckUntrackedLevels()
    c.level = math.max(c.level or 0, UnitLevel("player"))
    -- Erst nach dem Laden des Questlogs gelten neue Quests als "ohne Gruppe angenommen"
    C_Timer.After(20, function() PWF.questScanReady = true end)
    self:UpdateMoney()
    self:ScanProfessions()
    self:UpdateHonorKills()
    self:ScanQuestLog()
    self:CheckAchievements(not c.initialized)
    c.initialized = true
    self:UpdateGuildStatus()
    self:UpdateOwnRosterEntry()

    -- Spielzeit: kurz nach dem Login und dann alle 30 Min. abfragen, alle 5 Min. prüfen
    C_Timer.After(15, function() PWF:RequestPlayed() end)
    C_Timer.NewTicker(1800, function() PWF:RequestPlayed() end)
    C_Timer.NewTicker(300, function() PWF:CheckAchievements(false) end)
end

function PWF:ZONE_CHANGED_NEW_AREA() self:UpdateInstanceState() end
function PWF:PLAYER_LEVEL_UP(level) self:OnLevelChanged(level) end
function PWF:PLAYER_MONEY() self:OnMoneyChanged() end
function PWF:PLAYER_DEAD() self:OnPlayerDead() end
function PWF:SKILL_LINES_CHANGED() self:OnSkillsChanged() end
function PWF:COMBAT_LOG_EVENT_UNFILTERED() self:OnCombatLog() end
function PWF:ENCOUNTER_END(...) self:OnEncounterEnd(...) end
function PWF:PLAYER_GUILD_UPDATE() self:UpdateGuildStatus() end
function PWF:CHAT_MSG_ADDON(...) ns.Comm:OnMessage(...) end
function PWF:CHAT_MSG_SYSTEM(msg) self:OnSystemMessage(msg) end
function PWF:QUEST_TURNED_IN(questID) self:OnQuestTurnedIn(questID) end
function PWF:GROUP_ROSTER_UPDATE() self:OnGroupChanged() end
function PWF:TIME_PLAYED_MSG(total) self:OnTimePlayed(total) end

function PWF:PLAYER_PVP_KILLS_CHANGED()
    self:UpdateHonorKills()
    self:CheckAchievements(false)
end

function PWF:QUEST_LOG_UPDATE()
    if self.questTimer then return end
    self.questTimer = true
    C_Timer.After(1, function()
        PWF.questTimer = nil
        PWF:ScanQuestLog()
    end)
end

function PWF:GUILD_ROSTER_UPDATE()
    if not self.inGuild then self:UpdateGuildStatus() end
    self:UpdateGuildMembers()
end

-- Handel, Post und Gildenbank: Geldänderungen dort zählen nicht als "verdient"
function PWF:TRADE_SHOW() self.inTrade = true end
function PWF:TRADE_CLOSED()
    self.inTrade = false
    self.tradeGrace = GetTime() + 3
end
function PWF:MAIL_SHOW() self.atMail = true end
function PWF:MAIL_CLOSED() self.atMail = false end
function PWF:GUILDBANKFRAME_OPENED() self.atGuildBank = true end
function PWF:GUILDBANKFRAME_CLOSED()
    self.atGuildBank = false
    self.guildBankGrace = GetTime() + 2
end

local function IsGuildBanker(interactionType)
    return Enum and Enum.PlayerInteractionType and interactionType == Enum.PlayerInteractionType.GuildBanker
end
function PWF:PLAYER_INTERACTION_MANAGER_FRAME_SHOW(t)
    if IsGuildBanker(t) then self:GUILDBANKFRAME_OPENED() end
end
function PWF:PLAYER_INTERACTION_MANAGER_FRAME_HIDE(t)
    if IsGuildBanker(t) then self:GUILDBANKFRAME_CLOSED() end
end
