-- ============================================================================
--  PW Freetrans LoL - Gildenerfolge
--  Technische Einstellungen und Regeln.
--
--  Erfolge, Punkte, Ränge und Dungeons stehen NICHT hier, sondern in Data.lua.
--  Diese Datei wird automatisch aus Erfolgsliste/*.csv erzeugt
--  (Ins_Addon_uebernehmen.cmd).
-- ============================================================================
local ADDON, ns = ...

local C = {}
ns.Config = C

-- Das Addon funktioniert in jeder Gilde und auch ohne Gilde.
-- Rangliste, Klassenmeister und Datenaustausch gelten jeweils für die eigene Gilde.

-- Präfix für die unsichtbaren Addon-Nachrichten im Gildenkanal (max. 16 Zeichen).
C.COMM_PREFIX = "PWFreetrans"

-- Standard: neue Erfolge im Gildenchat ankündigen? (im Spiel mit /pwf ansage umschaltbar)
C.ANNOUNCE_IN_GUILD_DEFAULT = false

-- ----------------------------------------------------------------------------
--  Regeln gegen Ausnutzen
-- ----------------------------------------------------------------------------
C.DUNGEON_MAX_LEVEL_OVER = 5      -- Dungeon zählt nur bis Max-Stufe + 5
C.DUEL_MAX_LEVEL_BELOW = 5        -- Duellgegner höchstens 5 Stufen unter dir
C.DUEL_COOLDOWN = 3600            -- pro Gegner max. 1 gezählter Sieg pro Stunde
C.GUILD_RUN_MIN_MEMBERS = 3       -- Gildenrun ab 3 Gildenmitgliedern (inkl. dir)
C.SOLO_QUEST_MAX_LEVEL_BELOW = 3  -- Solo-Gruppenquest höchstens 3 Stufen unter dir

-- ----------------------------------------------------------------------------
--  Berufe: alle Schreibweisen, wie sie im Spiel angezeigt werden (DE + EN).
--  Der erste Name wird im Interface angezeigt.
--  secondary = Nebenberuf (zählt immer); Hauptberufe: nur die ersten zwei.
-- ----------------------------------------------------------------------------
C.PROFESSIONS = {
    { key = "ALCHEMY",        names = { "Alchemie", "Alchemy" } },
    { key = "BLACKSMITHING",  names = { "Schmiedekunst", "Blacksmithing" } },
    { key = "ENCHANTING",     names = { "Verzauberkunst", "Enchanting" } },
    { key = "ENGINEERING",    names = { "Ingenieurskunst", "Engineering" } },
    { key = "HERBALISM",      names = { "Kräuterkunde", "Herbalism" } },
    { key = "LEATHERWORKING", names = { "Lederverarbeitung", "Leatherworking" } },
    { key = "MINING",         names = { "Bergbau", "Mining" } },
    { key = "SKINNING",       names = { "Kürschnerei", "Skinning" } },
    { key = "TAILORING",      names = { "Schneiderei", "Tailoring" } },
    { key = "COOKING",        names = { "Kochkunst", "Cooking" },     secondary = true },
    { key = "FIRSTAID",       names = { "Erste Hilfe", "First Aid" }, secondary = true },
    { key = "FISHING",        names = { "Angeln", "Fishing" },        secondary = true },
}

-- Reihenfolge der Klassen im Gilden-Tab (neue Klassen werden hinten angehängt).
C.CLASS_ORDER = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }

-- Symbole je Kategorie (Kategorien ohne Eintrag bekommen das Fragezeichen)
C.CATEGORY_ICONS = {
    ["Stufen"]     = "Interface\\Icons\\Spell_Holy_HolyBolt",
    ["Gold"]       = "Interface\\Icons\\INV_Misc_Coin_01",
    ["Dungeons"]   = "Interface\\Icons\\INV_Misc_Head_Dragon_01",
    ["Berufe"]     = "Interface\\Icons\\Trade_BlackSmithing",
    ["Duelle"]     = "Interface\\Icons\\Ability_DualWield",
    ["PvP"]        = "Interface\\Icons\\Ability_Warrior_OffensiveStance",
    ["Ohne Tod"]   = "Interface\\Icons\\Spell_Holy_Resurrection",
    ["Gilde"]      = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
    ["Gildenbank"] = "Interface\\Icons\\INV_Misc_Coin_02",
    ["Quests"]     = "Interface\\Icons\\INV_Misc_Note_01",
    ["Spielzeit"]  = "Interface\\Icons\\INV_Misc_PocketWatch_01",
    ["Spaß"]       = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01",
}
C.DEFAULT_ICON = "Interface\\Icons\\INV_Misc_QuestionMark"
